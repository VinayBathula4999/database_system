import sqlite3

# Connect to the database
conn = sqlite3.connect('sales.db')

# Create a cursor object
cur = conn.cursor()

# Query the sales table
cur.execute('''SELECT * FROM sales''')
sales = cur.fetchall()

# Close the connection
conn.close()

# Print the sales data
for sale in sales:
    print(sale)
