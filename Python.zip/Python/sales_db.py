import csv

# Define constants for the hostnames of the database servers
HOST = "localhost"
HOST2 = "10.0.0.87"

# Define the names of the CSV files
PRODUCT_FILE = "products.csv"
CUSTOMER_FILE = "customers.csv"
SALES_FILE = "sales.csv"

# Define the encryption key for the customer account information
SECRET_KEY = "secretKey"

# Connect to the database
def connect_to_database(hostname):
    try:
        conn = csv.reader(open(hostname))
    except FileNotFoundError as e:
        print(e)
        exit(1)
    return conn

# Query the product table
def query_product_table(conn, product_id):
    for row in conn:
        if row[0] == product_id:
            return row
    return None

# Query the customer table
def query_customer_table(conn, customer_id):
    for row in conn:
        if row[0] == customer_id:
            return row
    return None

# Insert a new sales record
def insert_sales_record(conn, customer_id, product_id, quantity):
    conn.writerow([customer_id, product_id, quantity])

# Print the menu
def print_menu():
    print("1. View product table")
    print("2. View customer table")
    print("3. View sales table")
    print("4. Place an order")
    print("Q. Quit")

# Get the user's choice
def get_user_choice():
    choice = input("Enter your choice: ")
    return choice

# Main function
def main():
    # Connect to the database
    conn_product = connect_to_database(PRODUCT_FILE)
    conn_customer = connect_to_database(CUSTOMER_FILE)
    conn_sales = connect_to_database(SALES_FILE)

    # Print the menu
    print_menu()

    # Get the user's choice
    choice = get_user_choice()

    # Handle the user's choice
    while choice != "Q":
        if choice == "1":
            # View the product table
            for row in conn_product:
                print(row)
        elif choice == "2":
            # View the customer table
            for row in conn_customer:
                print(row)
        elif choice == "3":
            # View the sales table
            for row in conn_sales:
                print(row)
        elif choice == "4":
            # Place an order

            # Get the customer ID
            customer_id = input("Enter the customer ID: ")

            # Get the product ID
            product_id = input("Enter the product ID: ")

            # Get the quantity
            quantity = input("Enter the quantity: ")

            # Insert the new sales record
            insert_sales_record(conn_sales, customer_id, product_id, quantity)

            # Print a confirmation message
            print("Order placed successfully!")
        else:
            print("Invalid choice")

        # Print the menu again
        print_menu()

        # Get the user's choice again
        choice = get_user_choice()

    # Close the database connections
    conn_product.close()
    conn_customer.close()
    conn_sales.close()

if __name__ == "__main__":
    main()
