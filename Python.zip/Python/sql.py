import sqlite3

# Connect to the database
conn = sqlite3.connect('sales.db')

# Create a cursor object
cur = conn.cursor()

# Create the sales table
cur.execute('''CREATE TABLE IF NOT EXISTS sales (
    customer_id INTEGER,
    product_id INTEGER,
    quantity INTEGER
)''')

# Query the product table
cur.execute('''SELECT * FROM products''')
products = cur.fetchall()

# Query the customer table
cur.execute('''SELECT * FROM customers''')
customers = cur.fetchall()

# Create an empty sales table
for customer in customers:
    for product in products:
        cur.execute('''INSERT INTO sales (customer_id, product_id, quantity) VALUES (?, ?, ?)''', (customer[0], product[0], 0))

# Commit the changes
conn.commit()

# Close the connection
conn.close()
