import sqlite3

# Connect to the database
conn = sqlite3.connect('products.db')

# Create a cursor object
cur = conn.cursor()

# Create the products table
cur.execute('''CREATE TABLE IF NOT EXISTS products (
    product_id INTEGER PRIMARY KEY,
    product_name VARCHAR(255) NOT NULL,
    cost DECIMAL(5,2) NOT NULL,
    in_stock INTEGER NOT NULL
)''')

# Insert the product data
cur.executemany('''INSERT INTO products (product_id, product_name, cost, in_stock) VALUES (?, ?, ?, ?)''', [
    (1, 'argle', 5.00, 100),
    (2, 'bargle', 2.50, 200),
    (3, 'cargle', 1.25, 200)
])

# Create the customers table
cur.execute('''CREATE TABLE IF NOT EXISTS sales (
    customer_id INTEGER NOT NULL,
    customer_name VARCHAR(255) NOT NULL,
)''')

# Insert the sales data
cur.executemany('''INSERT INTO sales (customer_id, customer_name) VALUES (?, ?)''', [
    (1, Archie),
    (2, Buddy)
])

# Commit the changes
conn.commit()

# Close the connection
conn.close()
