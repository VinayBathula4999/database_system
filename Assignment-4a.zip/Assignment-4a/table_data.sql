# Load customer data
LOAD DATA LOCAL INFILE '\D:\Archana_Docs\Masters\Assignments\Vinay\Database_Systems\Assignment-4\customers.csv'
INTO TABLE `customers`
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 LINES;

# Load order data
LOAD DATA LOCAL INFILE '\D:\Archana_Docs\Masters\Assignments\Vinay\Database_Systems\Assignment-4\orders.csv'
INTO TABLE `orders`
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 LINES;

# Load order item data
LOAD DATA LOCAL INFILE '\D:\Archana_Docs\Masters\Assignments\Vinay\Database_Systems\Assignment-4\order_items.csv'
INTO TABLE `order_items`
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 LINES;

# Load product data
LOAD DATA LOCAL INFILE '\D:\Archana_Docs\Masters\Assignments\Vinay\Database_Systems\Assignment-4\products.csv'
INTO TABLE `products`
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 LINES;

# Load category data
LOAD DATA LOCAL INFILE '\D:\Archana_Docs\Masters\Assignments\Vinay\Database_Systems\Assignment-4\categories.csv'
INTO TABLE `categories`
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 LINES;
